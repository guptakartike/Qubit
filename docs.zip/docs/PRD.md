# Qubit — Product Requirements Document (PRD)

## 1. Problem Statement

### Problem

Small and medium-sized software teams and startups often use multiple disconnected tools for communication, documentation, task management, and project coordination. Information becomes fragmented across Slack, Notion, Jira, Trello, Google Drive, and other tools.

Qubit aims to provide a unified collaborative workspace where teams can manage communication, documentation, and tasks from one platform.

### Who experiences this problem?

- Small and medium-sized software teams
- Startups
- Engineering teams
- Product teams
- Project managers and team leads
- Developers and other knowledge workers

### Why does this matter?

Switching between multiple applications creates fragmented context, duplicated information, and poor visibility into project activity. Qubit aims to centralize the core collaboration workflow without trying to replace every existing tool in its first version.

---

## 2. Target User

### Primary User

Small and medium-sized software teams and startups that need a centralized platform for managing collaborative work.

Typical users include:

- Developers
- Engineering managers
- Product managers
- Designers
- Startup founders
- Project/team leads

### User Goals

Users want to:

- Organize their team into workspaces
- Communicate with teammates
- Create and manage project documentation
- Track tasks and project progress
- Control access to workspace resources
- Quickly find relevant project information

### User Frustrations

- Information spread across multiple applications
- Difficulty finding project context
- Repeated switching between communication and task-management tools
- Poor visibility into team activity
- Inconsistent permissions across different systems
- Duplicate information between documentation and task-management tools

---

## 3. Core Features — MVP

The MVP focuses on building a strong collaborative workspace rather than implementing every planned Qubit feature.

### 3.1 Authentication

Users can:

- Register with email and password
- Log in
- Verify their email
- Refresh authentication sessions
- Log out
- Manage active sessions
- Sign in with Google
- Sign in with GitHub

Authentication must use secure password hashing, refresh-token/session management, validation, and backend-enforced authorization.

### 3.2 Organizations & Workspaces

Users can:

- Create an organization
- Create multiple workspaces within an organization
- Invite members
- Join workspaces
- Switch between workspaces
- Manage workspace membership

Initial roles:

- Owner
- Admin
- Manager
- Member
- Guest

Permissions must be enforced by the backend rather than relying on frontend restrictions.

### 3.3 Documents

Users can create and manage workspace documents.

MVP capabilities:

- Create documents
- Edit documents
- Delete/archive documents
- Organize documents
- Rich text editing
- Basic Markdown support
- Document permissions
- Document metadata
- Last-edited information

The architecture should leave room for future real-time collaborative editing and version history.

### 3.4 Task Management

Users can manage work using a Kanban-style task system.

MVP capabilities:

- Create tasks
- Assign tasks
- Update task status
- Set priority
- Add labels
- Set due dates
- Add comments
- Track task activity

The system should support a board/backlog model that can later evolve toward more advanced Jira-style functionality.

### 3.5 Workspace Chat

Users can communicate inside a workspace.

MVP capabilities:

- Workspace channels
- Direct messages
- Send messages
- Message history
- Mentions
- Basic reactions
- Basic real-time message delivery

WebSockets should be used for real-time communication where appropriate.

### Nice to Have — Post-MVP

- Advanced real-time document collaboration
- Cursor presence
- Conflict resolution
- Threads
- Read receipts
- Typing indicators
- Calendar
- File storage and previews
- Global search
- Notifications
- Activity analytics
- AI document summarization
- AI writing assistant
- AI task generation
- Natural-language workspace search
- Meeting-note generation
- Advanced document version history
- Sprints and advanced backlog management

---

## 4. Out of Scope for V1

The following are explicitly outside the first production MVP:

- Native mobile applications
- Desktop applications
- Google Docs-level collaborative editing
- Full Jira replacement
- Full Slack replacement
- Advanced calendar management
- Large-scale video conferencing
- Complex enterprise billing
- Marketplace/app ecosystem
- Advanced AI agent workflows
- Complex workflow automation
- Microservice architecture
- Multi-region deployment
- Globally distributed database architecture

These can be considered after the core platform is stable.

---

## 5. Product Differentiation

Qubit should initially differentiate through **unified context**.

Instead of merely placing several tools in one application, Qubit should connect them:

```text
Chat discussion
      ↓
Task
      ↓
Document
      ↓
Project activity
```

Users should be able to move between related conversations, tasks, and documents without losing context.

### Long-Term Differentiator: Context-Aware AI

AI should eventually operate on the team's actual workspace context rather than functioning as a generic chatbot.

Examples:

- "Summarize what happened on Project X this week."
- "Create tasks from this discussion."
- "What decisions were made about authentication?"
- "What are the blockers for the current sprint?"

AI is therefore a future capability built on top of structured workspace data, not the core MVP.

---

## 6. Success Metrics

### KPI 1 — Workspace Activation

Percentage of newly registered users who create or join a workspace and perform at least one meaningful collaboration action.

**Initial target:** >60% activation during early testing.

### KPI 2 — Collaboration Activity

Percentage of active workspaces where users perform multiple collaboration actions such as:

- Creating/editing documents
- Creating/updating tasks
- Sending messages

**Initial target:** >50% of active workspaces showing recurring collaboration activity.

### KPI 3 — Reliability

Production MVP targets:

- API error rate <1% under expected application traffic
- No critical authentication/security vulnerabilities
- Automated tests covering critical backend flows
- Database migrations reproducible from a clean database
- Containerized deployment

---

## 7. Technical Assumptions

### Platform

**Web application**

### Frontend

- React
- TypeScript
- Vite
- Tailwind CSS
- shadcn/ui
- TanStack Query
- React Router
- Zustand

### Backend

- Go
- Gin
- PostgreSQL
- Redis

The backend will use a **modular monolith** architecture.

Initial modules:

```text
Authentication
Organizations
Workspaces
Documents
Tasks
Chat
Notifications
Storage
Search
AI
```

Only modules required for the MVP should initially be implemented.

### Database

PostgreSQL.

Requirements:

- Relational data modeling
- Foreign keys
- Unique constraints
- Appropriate indexes
- Transactions for multi-step operations
- Versioned migrations
- Soft deletion where historical relationships require preservation

### Authentication

- Email/password
- Argon2id password hashing
- Google OAuth
- GitHub OAuth
- Short-lived access tokens
- Refresh-token/session management
- Email verification
- Session revocation
- Backend-enforced authorization

### Realtime

WebSockets for features requiring live communication.

Initial use case:

- Real-time workspace chat

Future use cases:

- Document collaboration
- Presence
- Typing indicators
- Live notifications

### Storage

MinIO using an S3-compatible API for development and early deployment.

Storage should be abstracted behind an interface so the implementation can later move to AWS S3 or another compatible provider.

### Infrastructure

- Docker
- Docker Compose
- GitHub Actions
- Environment-based configuration
- Structured logging
- Automated tests
- Swagger/OpenAPI documentation

### Architecture Principle

Qubit starts as a **modular monolith**, not microservices.

Modules should have clear boundaries so that high-load modules can eventually be extracted into independent services if actual scaling requirements justify it.

---

## 8. Open Questions

### 1. Organization vs Workspace Permissions

The exact permission inheritance model between organization-level roles and workspace-level roles needs to be finalized.

```text
Organization
      ↓
Workspace
      ↓
Resource
```

The system must define exactly how permissions propagate through these levels.

### 2. Company Email Rules

Qubit needs a final policy for users using company domains versus personal email addresses.

Questions include:

- Can a company domain automatically associate a user with an organization?
- Can the same user belong to multiple organizations?
- Who controls company-domain ownership?
- How are organization invitations handled?

### 3. Document Collaboration Model

The MVP can initially use standard request/response document editing.

Future real-time collaboration may require:

- CRDTs
- Operational Transformation
- WebSocket synchronization
- Presence management
- Version history

The exact collaboration architecture should be decided when real-time document editing is introduced.

### 4. Search Architecture

The MVP can initially use PostgreSQL search capabilities.

As the dataset grows, Qubit may introduce a dedicated search engine such as OpenSearch or Elasticsearch depending on actual requirements.

### 5. AI Architecture

The AI layer needs decisions around:

- Supported model providers
- Workspace-data retrieval
- Embeddings/vector search
- Tenant isolation
- Sensitive workspace-data protection
- User confirmation for AI actions

---

## MVP User Flow

```text
Register
   ↓
Verify Email
   ↓
Login
   ↓
Create Organization
   ↓
Create Workspace
   ↓
Invite Team Members
   ↓
Create Channel
   ↓
Send Messages
   ↓
Create Document
   ↓
Create Tasks
   ↓
Collaborate
   ↓
View Workspace Activity
```

The MVP is successful when a small software team can use Qubit to organize a real project without immediately depending on separate tools for basic **communication, documentation, and task management**.

---

## Product Development Principle

**Quality > Feature Count**

Every major feature should be:

- Properly architected
- Secure
- Tested
- Documented
- Observable
- Maintainable
- Designed with future scalability in mind

The MVP should be small enough to finish but strong enough to demonstrate production-grade software engineering.

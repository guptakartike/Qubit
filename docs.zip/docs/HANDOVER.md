# Qubit — Handover

> This file is the starting point for every new AI-assisted development session.

## Project

Qubit is a production-oriented collaborative workspace platform for small/medium software teams and startups.

Architecture:
- Modular monolith
- Web application
- Backend: Go + Gin
- Database: PostgreSQL
- Cache/realtime infrastructure: Redis + WebSockets
- Frontend: React + TypeScript + Vite

## Current Status

### Completed
- Go backend initialized
- HTTP server running
- Health endpoint implemented
- Environment configuration started
- PostgreSQL connected
- pgx connection pool configured
- golang-migrate configured
- `users` table created
- `password_credentials` table created
- Migration 001 applied
- Migration 002 applied

### Current Database
```text
users
  └── password_credentials

schema_migrations
```

### Current Authentication Model
```text
users
 ├── password_credentials
 ├── oauth_accounts       # planned
 └── sessions              # planned
```

### Current Task

Continue implementing authentication.

Immediate next work:
1. Design registration validation
2. Implement Argon2id password hashing
3. Implement registration service
4. Use a PostgreSQL transaction for user + credentials creation
5. Implement registration handler/API
6. Add tests
7. Commit the completed milestone

## Important Decisions

- User IDs: UUIDv7
- Emails: normalized to lowercase before storage
- Email uniqueness enforced by PostgreSQL
- Password hashes are stored separately from user identity data
- Password hashing: Argon2id
- Account deletion: soft deletion using `deleted_at`
- Authentication providers: email/password, Google, GitHub
- Sessions/refresh tokens will be modeled separately
- Qubit starts as a modular monolith, not microservices

## Current Database Schema

### users
- `id UUID PRIMARY KEY`
- `name VARCHAR(100) NOT NULL`
- `email VARCHAR(255) NOT NULL UNIQUE`
- `status`
- `email_verified_at TIMESTAMPTZ`
- `deleted_at TIMESTAMPTZ`
- `created_at TIMESTAMPTZ`
- `updated_at TIMESTAMPTZ`

### password_credentials
- `user_id UUID PRIMARY KEY`
- `password_hash TEXT NOT NULL`
- `created_at TIMESTAMPTZ`
- `updated_at TIMESTAMPTZ`
- foreign key to `users(id)`
- `ON DELETE CASCADE`

## Rules for AI Sessions

- Do not rewrite working architecture without a reason.
- Do not introduce microservices prematurely.
- Do not dump large amounts of code.
- Explain the engineering decision before implementation.
- Create files only when the feature actually requires them.
- Keep modules independently understandable.
- Prefer secure, testable, production-oriented solutions.
- Tell the developer when a decision has a meaningful trade-off.
- Never silently change an architectural decision.
- Update `DECISIONS.md` when a significant technical decision is made.
- Update `FLOW.md` when execution flow changes.
- Update `BUGS.md` or `FEATURES.md` when the relevant work is completed.

## Git Rule

Commit after each meaningful, working milestone.

Commit messages should use conventional-style prefixes:

```text
feat:
fix:
refactor:
test:
docs:
chore:
```

# Qubit — Feature Development Log

Track meaningful features from planning through verification.

Each feature should have a complete trail so a future developer or AI session can understand what was built and why.

---

## Feature Template

```markdown
## FEAT-XXX — Feature name

**Status:** Planned / In Progress / Implemented / Verified

### Goal

What user problem does this feature solve?

### Scope

What is included?

### Out of Scope

What is intentionally excluded?

### Design

How does the feature work?

### Database Changes

List migrations/tables/indexes.

### API Changes

List endpoints and contracts.

### Implementation

List important files/modules.

### Edge Cases

What can go wrong?

### Security

What security concerns exist?

### Testing

What was tested?

### Verification

How was successful behavior confirmed?

### Related Decisions

Link or reference relevant entries in `DECISIONS.md`.
```

---

## FEAT-001 — User Identity & Account Schema

**Status:** Implemented

### Goal

Create the foundational user identity model required for authentication and all future Qubit features.

### Scope

Implemented:

- User identity
- Canonical email
- Account status
- Email verification timestamp
- Soft deletion
- Creation/update timestamps

### Database

Migration:

```text
001_create_users
```

Table:

```text
users
```

### Verification

PostgreSQL schema inspected successfully.

---

## FEAT-002 — Password Credentials

**Status:** Implemented

### Goal

Separate password authentication data from general user identity data.

### Scope

Implemented:

- One-to-one password credential relationship
- Password hash storage
- Foreign key to users
- Creation/update timestamps
- Cascade behavior for permanent user deletion

### Database

Migration:

```text
002_create_password_credentials
```

Table:

```text
password_credentials
```

### Security

Passwords will be stored as Argon2id hashes.

Plaintext passwords must never be persisted.

### Verification

Migration applied successfully and database schema inspected.

---

## FEAT-003 — User Registration

**Status:** Planned

### Goal

Allow a new user to create a Qubit account securely.

### Planned Flow

```text
Register
  ↓
Validate
  ↓
Normalize email
  ↓
Hash password
  ↓
Begin transaction
  ↓
Create user
  ↓
Create credentials
  ↓
Commit
  ↓
Return safe user data
```

### Out of Scope

- OAuth registration
- Email verification delivery
- Login
- Refresh tokens

Those will be separate milestones.

---

# Feature Development Rule

Every meaningful feature should move through:

```text
Planned
   ↓
Designed
   ↓
Implemented
   ↓
Tested
   ↓
Verified
   ↓
Committed
```

Do not mark a feature implemented merely because the code compiles.

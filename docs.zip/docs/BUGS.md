# Qubit — Bug Log

Track meaningful bugs from discovery to verification.

Do not use this as a dumping ground for every typo or temporary development issue.

---

## Bug Template

```markdown
## BUG-XXX — Short description

**Status:** Open / Investigating / Fixed / Verified

### Symptoms

What is happening?

### Reproduction

How can the bug be reproduced?

### Root Cause

Why is it happening?

### Attempted Solutions

What was tried?

### Fix

What changed?

### Verification

How was the fix tested?

### Related Files

- `path/to/file`
```

---

## BUG-001 — Migration CLI SSL Connection

**Status:** Fixed

### Symptoms

`golang-migrate` failed with:

```text
pq: SSL is not enabled on the server
```

### Root Cause

The local PostgreSQL server does not use SSL, while the connection string did not explicitly disable SSL.

### Fix

Use:

```text
?sslmode=disable
```

for local development.

Example:

```bash
migrate -path migrations -database "postgres://kartikegupta@localhost:5432/qubit?sslmode=disable" up
```

### Verification

Migration version returned:

```text
2
```

and PostgreSQL showed both:

```text
schema_migrations
users
password_credentials
```

### Production Note

`sslmode=disable` is a local-development configuration and should not automatically be carried into production.

---

## BUG-002 — DATABASE_URL Empty in Shell

**Status:** Expected / Development Configuration

### Symptoms

Running:

```bash
migrate -path migrations -database "$DATABASE_URL" version
```

returned:

```text
URL cannot be empty
```

### Root Cause

`.env` is not automatically exported into the shell environment. The Go application loads environment configuration separately.

### Current Development Approach

Use the explicit local database connection string for migration CLI commands.

### Future Improvement

Introduce a documented environment-loading workflow so local development tools can consistently use the same configuration without exposing secrets.

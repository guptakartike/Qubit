# Qubit — Execution Flow

This document records how requests travel through the application.

The goal is to make execution paths understandable without reverse-engineering the entire codebase.

---

## Backend Request Flow

Expected general flow:

```text
HTTP Request
     ↓
Gin Router
     ↓
Middleware
     ↓
Handler
     ↓
Service
     ↓
Repository / Database
     ↓
PostgreSQL
     ↓
Repository
     ↓
Service
     ↓
Handler
     ↓
HTTP Response
```

### Responsibilities

#### Router

Maps HTTP methods and paths to handlers.

Example:

```text
POST /api/v1/auth/register
        ↓
RegisterHandler
```

#### Middleware

Handles cross-cutting concerns such as:
- authentication
- request IDs
- logging
- recovery
- CORS
- rate limiting

#### Handler

Responsible for:
- reading HTTP input
- validating request shape
- calling the service
- converting results/errors into HTTP responses

Handlers should not contain business logic.

#### Service

Contains application/business logic.

Examples:
- normalize email
- validate registration rules
- hash password
- coordinate transaction
- enforce business rules

#### Repository

Responsible for database access.

Repositories should not contain HTTP concerns.

---

# Current Registration Flow

Planned flow:

```text
POST /api/v1/auth/register
        ↓
RegisterHandler
        ↓
Parse request
        ↓
Validate name/email/password
        ↓
Normalize email
        ↓
Registration Service
        ↓
Begin PostgreSQL transaction
        ↓
Create user
        ↓
Hash password
        ↓
Create password credential
        ↓
Commit
        ↓
Return safe user response
```

### Failure flow

```text
Begin transaction
       ↓
Create user
       ↓
Credential creation fails
       ↓
Rollback
       ↓
Return appropriate error
```

No partial account should remain.

---

# Authentication Flow — Planned

## Login

```text
POST /api/v1/auth/login
        ↓
Validate input
        ↓
Normalize email
        ↓
Find user
        ↓
Find password credential
        ↓
Verify Argon2id hash
        ↓
Create session / refresh token
        ↓
Issue access token
        ↓
Return authenticated response
```

## OAuth

```text
Client
  ↓
OAuth provider
  ↓
Callback
  ↓
Validate provider identity
  ↓
Find/link OAuth account
  ↓
Create or resolve Qubit user
  ↓
Create session
  ↓
Issue authentication tokens
```

---

# Authorization Flow — Planned

```text
Request
  ↓
Access Token
  ↓
Authenticate User
  ↓
Identify Organization/Workspace
  ↓
Resolve Membership
  ↓
Check Role/Permission
  ↓
Allow or Reject
```

Authentication answers:

```text
Who are you?
```

Authorization answers:

```text
Are you allowed to do this?
```

---

# Database Transaction Flow

For multi-step operations:

```text
BEGIN
  ↓
Operation A
  ↓
Operation B
  ↓
Operation C
  ↓
COMMIT
```

If any required operation fails:

```text
ROLLBACK
```

---

# Rule

When a new module or important endpoint is added, update this file with its real execution path.
